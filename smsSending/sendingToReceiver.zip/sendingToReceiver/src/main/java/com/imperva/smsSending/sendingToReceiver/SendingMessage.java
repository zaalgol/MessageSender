package com.imperva.smsSending.sendingToReceiver;

import com.imperva.smsSending.models.Message;

import java.util.Random;

public class SendingMessage {
    final Random random = new Random();

    public boolean sendMessage(Message messages) {
        // System.out.println("****  false");
        // return false;

        // simulates 2/3% success
        boolean success =  random.nextInt(3) > 0;
        System.out.println("Message id:" + messages.getId() +  "   " + success + " success");
        return success;
    }
}
